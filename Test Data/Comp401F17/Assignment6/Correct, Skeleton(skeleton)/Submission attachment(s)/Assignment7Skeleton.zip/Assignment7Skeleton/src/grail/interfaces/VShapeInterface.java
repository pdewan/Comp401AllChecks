package grail.interfaces;

import util.annotations.Tags;

@Tags({"Angle", "move"})
public interface VShapeInterface extends Locatable{

}
