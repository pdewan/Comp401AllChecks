package grail.collections;

import grail.interfaces.BaseHistory;
import grail.interfaces.Token;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;

@StructurePattern(StructurePatternNames.VECTOR_PATTERN)
public class ABaseHistory implements BaseHistory {
	
}
