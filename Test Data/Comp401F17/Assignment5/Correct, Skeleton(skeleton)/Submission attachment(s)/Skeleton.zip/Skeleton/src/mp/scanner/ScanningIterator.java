package mp.scanner;

import java.util.Iterator;

public class ScanningIterator {

}
