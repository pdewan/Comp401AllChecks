package grail.interfaces;

import util.annotations.Tags;

@Tags({"Avatar", "move"})
public interface AvatarInterface {

}
