package grail.interfaces;
import util.annotations.Tags;

@Tags({"Word"})
public interface Word extends Token {
}
