package grail.interfaces;

import util.annotations.Tags;

@Tags({"Number"})
public interface Number extends Token {
}
