package grail.interfaces;
import util.annotations.Tags;

@Tags({"Start"})
public interface Start extends Token{

}
