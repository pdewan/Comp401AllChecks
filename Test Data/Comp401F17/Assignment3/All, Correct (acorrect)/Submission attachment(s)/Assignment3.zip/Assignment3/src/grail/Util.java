package grail;

public class Util {
	public static boolean isLetter(char c)
	{
		return 'a'<=c&&c<='z'||'A'<=c&&c<='Z';
	}
}
