package main;

import bus.uigen.OEFrame;
import bus.uigen.ObjectEditor;
import grail.graphics.BridgeScene;
import grail.interfaces.BridgeSceneInterface;
import util.misc.ThreadSupport;

public class Assignment5 {
	
	public static void main(String[] args) {
		
	}//end main
}//end class
