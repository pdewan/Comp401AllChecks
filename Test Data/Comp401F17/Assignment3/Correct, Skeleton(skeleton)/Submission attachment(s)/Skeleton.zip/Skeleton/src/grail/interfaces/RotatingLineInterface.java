package grail.interfaces;

import util.annotations.Tags;

@Tags({"RotatingLine", "rotate"})
public interface RotatingLineInterface {
}
