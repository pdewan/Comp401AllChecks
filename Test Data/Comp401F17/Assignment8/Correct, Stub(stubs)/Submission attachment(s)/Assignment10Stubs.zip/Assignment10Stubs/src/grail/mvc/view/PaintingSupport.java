package grail.mvc.view;

import java.awt.Graphics2D;
import java.awt.Toolkit;

import grail.interfaces.AvatarInterface;
import grail.interfaces.BoundedShapeInterface;
import grail.interfaces.ImageInterface;
import grail.interfaces.RotatingLineInterface;
import grail.interfaces.StringShapeInterface;
import grail.interfaces.VShapeInterface;

public class PaintingSupport {
	
}
