package grail.interfaces;

public interface CommandThread extends Runnable{

}
