package grail.interfaces.mvc;

import util.annotations.Tags;

@Tags({"DelegatingBridgeSceneView"})
public interface DelegatingBridgeSceneViewInterface {

}
