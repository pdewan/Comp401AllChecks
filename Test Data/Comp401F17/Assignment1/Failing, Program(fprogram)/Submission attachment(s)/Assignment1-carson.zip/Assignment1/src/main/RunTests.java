package main;
import gradingTools.comp401f17.assignment1.testcases.Assignment1Suite;

public class RunTests {
	public static void main(String [] args) {
		Assignment1Suite.main(args);
	}

}
