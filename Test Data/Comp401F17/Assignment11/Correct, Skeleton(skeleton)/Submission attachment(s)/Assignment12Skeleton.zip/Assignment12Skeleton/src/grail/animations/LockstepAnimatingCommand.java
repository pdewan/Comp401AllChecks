package grail.animations;

import grail.interfaces.AnimatorInterface;
import grail.interfaces.AvatarInterface;
import grail.interfaces.CommandThread;
import util.annotations.Tags;

@Tags({"CoordinatedAnimator"})
public class LockstepAnimatingCommand implements CommandThread {


}
