package grail.interfaces;

import util.annotations.Tags;

/**
 * Only exists to fulfill requirements regarding public methods being
 * in interfaces
 *
 */
@Tags({"ParsingException"})
public interface ParsingExceptionInterface {

}