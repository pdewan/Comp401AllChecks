package grail.scanner.commands;

import grail.interfaces.AvatarInterface;
import grail.interfaces.CommandThread;
import util.annotations.Tags;

@Tags({"RotateRightArmCommandObject"})
public class RotateRightArmCommand implements CommandThread {

}
