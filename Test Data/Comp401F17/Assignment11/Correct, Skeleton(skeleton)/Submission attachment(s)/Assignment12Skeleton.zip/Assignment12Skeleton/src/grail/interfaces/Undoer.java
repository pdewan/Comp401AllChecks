package grail.interfaces;

public interface Undoer {
}
