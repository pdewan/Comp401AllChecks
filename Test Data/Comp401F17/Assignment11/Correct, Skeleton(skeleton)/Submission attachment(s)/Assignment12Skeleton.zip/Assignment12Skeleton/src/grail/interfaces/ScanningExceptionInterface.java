package grail.interfaces;

/**
 * Only exists to fulfill requirements regarding public methods being
 * in interfaces
 *
 */
public interface ScanningExceptionInterface {
}