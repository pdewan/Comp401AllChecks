package mp.scanner;

import java.util.Iterator;

public class ScanningIterator implements Iterator<String>{

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String next() {
		// TODO Auto-generated method stub
		return null;
	}

}
