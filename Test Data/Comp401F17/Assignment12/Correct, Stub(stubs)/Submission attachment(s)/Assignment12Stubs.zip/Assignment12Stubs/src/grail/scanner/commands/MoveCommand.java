package grail.scanner.commands;

import grail.interfaces.AvatarInterface;
import grail.interfaces.CommandThread;
import grail.interfaces.UndoableCommandThread;
import util.annotations.Tags;

@Tags({"MoveCommand"})
public class MoveCommand implements UndoableCommandThread{
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}
}
