package grail.mvc.view;

import grail.SingletonsCreator;
import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.mvc.DelegatingBridgeSceneViewInterface;
import grail.interfaces.mvc.PaintingViewMaster;
import util.annotations.Tags;

@Tags({"DelegatingBridgeSceneView"})
public class DelegatingBridgeSceneView implements DelegatingBridgeSceneViewInterface{

	
}
