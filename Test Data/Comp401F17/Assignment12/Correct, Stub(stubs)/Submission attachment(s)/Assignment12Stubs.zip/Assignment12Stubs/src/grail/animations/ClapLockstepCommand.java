package grail.animations;

import grail.interfaces.AnimatorInterface;
import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.CommandThread;
import util.annotations.Tags;

@Tags({"CoordinatingAnimatingCommand"})
public class ClapLockstepCommand implements CommandThread{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
