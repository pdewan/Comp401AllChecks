package grail.scanner.commands;

import grail.animations.fromJavaTeaching.BroadcastingClearanceManager;
import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.CommandThread;
import util.annotations.Tags;
import util.misc.ThreadSupport;
@Tags({"ProceedAllCommand"})
public class ProceedAllCommand implements CommandThread{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
