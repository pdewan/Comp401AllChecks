package grail.scanner.commands;

import grail.interfaces.AvatarInterface;
import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.CommandThread;
import util.annotations.Tags;

@Tags({"ApproachCommand"})
public class ApproachCommand implements CommandThread{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}


}
