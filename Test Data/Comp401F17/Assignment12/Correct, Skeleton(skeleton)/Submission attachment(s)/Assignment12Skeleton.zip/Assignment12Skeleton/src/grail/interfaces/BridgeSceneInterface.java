package grail.interfaces;

import util.annotations.Tags;
import util.models.PropertyListenerRegisterer;

@Tags({"BridgeScene"})
public interface BridgeSceneInterface {
	
}
