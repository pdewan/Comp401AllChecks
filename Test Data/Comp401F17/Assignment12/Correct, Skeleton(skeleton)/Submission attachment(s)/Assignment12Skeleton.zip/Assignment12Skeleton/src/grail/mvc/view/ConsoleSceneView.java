package grail.mvc.view;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import grail.SingletonsCreator;
import grail.interfaces.BridgeSceneInterface;
import util.annotations.Tags;

@Tags({"ConsoleSceneView"})
public class ConsoleSceneView {

}
