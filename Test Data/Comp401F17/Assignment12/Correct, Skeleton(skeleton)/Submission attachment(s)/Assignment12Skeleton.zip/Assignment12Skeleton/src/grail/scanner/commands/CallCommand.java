package grail.scanner.commands;

import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.CommandThread;
import grail.interfaces.Table;
import util.annotations.Tags;
import util.misc.ThreadSupport;

@Tags({"CallCommandObject"})
public class CallCommand implements CommandThread{

}
