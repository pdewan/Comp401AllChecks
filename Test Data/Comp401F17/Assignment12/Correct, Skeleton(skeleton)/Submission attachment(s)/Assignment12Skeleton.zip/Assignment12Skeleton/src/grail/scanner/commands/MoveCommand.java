package grail.scanner.commands;

import grail.interfaces.AvatarInterface;
import grail.interfaces.CommandThread;
import grail.interfaces.UndoableCommandThread;
import util.annotations.Tags;

@Tags({"MoveCommand"})
public class MoveCommand implements UndoableCommandThread{

}
