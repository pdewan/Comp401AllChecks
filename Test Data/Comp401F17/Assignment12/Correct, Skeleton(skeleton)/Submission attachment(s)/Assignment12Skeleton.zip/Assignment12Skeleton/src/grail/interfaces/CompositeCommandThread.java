package grail.interfaces;

public interface CompositeCommandThread extends CommandThread{

}
