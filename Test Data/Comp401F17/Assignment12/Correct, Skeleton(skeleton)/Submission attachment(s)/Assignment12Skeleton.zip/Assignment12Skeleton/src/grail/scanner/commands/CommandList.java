package grail.scanner.commands;

import java.util.ArrayList;
import java.util.List;

import grail.interfaces.CompositeCommandThread;
import util.annotations.Tags;

@Tags({"CommandList"})
public class CommandList implements CompositeCommandThread{

}
