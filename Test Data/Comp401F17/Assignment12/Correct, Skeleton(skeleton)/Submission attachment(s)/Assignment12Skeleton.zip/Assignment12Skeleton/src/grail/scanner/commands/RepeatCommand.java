package grail.scanner.commands;

import grail.interfaces.CommandThread;
import util.annotations.Tags;

@Tags({"RepeatCommand"})
public class RepeatCommand implements CommandThread{


}
