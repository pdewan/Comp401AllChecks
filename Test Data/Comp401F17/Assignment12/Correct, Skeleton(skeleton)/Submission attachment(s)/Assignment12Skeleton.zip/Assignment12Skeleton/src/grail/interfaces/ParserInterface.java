package grail.interfaces;

import util.annotations.Tags;

@Tags({"Parser"})
public interface ParserInterface {

}