package grail.scanner;

import java.util.Iterator;

public class ScanningIterator {

}
