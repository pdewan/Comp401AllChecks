package grail.interfaces;

public interface UndoableCommandThread extends CommandThread {
}
