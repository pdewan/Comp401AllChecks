package grail.interfaces;

import grail.scanner.ScanningException;
import util.annotations.Tags;

@Tags({"ScannerBean"})
public interface ScannerBeanInterface {
}
