package grail.graphics;

import grail.interfaces.Locatable;

public abstract class LocatableObject implements Locatable{

}
