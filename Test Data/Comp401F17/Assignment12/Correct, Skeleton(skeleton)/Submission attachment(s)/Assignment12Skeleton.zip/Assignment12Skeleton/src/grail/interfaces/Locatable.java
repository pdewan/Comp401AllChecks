package grail.interfaces;

import util.annotations.Tags;

@Tags({"Locatable"})
public interface Locatable {
	
}
