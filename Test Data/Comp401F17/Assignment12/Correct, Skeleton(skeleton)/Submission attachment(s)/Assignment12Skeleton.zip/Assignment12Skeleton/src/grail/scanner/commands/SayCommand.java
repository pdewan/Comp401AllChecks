package grail.scanner.commands;

import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.CommandThread;
import util.annotations.Tags;

@Tags({"SayCommand"})
public class SayCommand implements CommandThread{

}
