package grail.interfaces;

public interface UndoableCommandThread extends CommandThread {
	public void undo();
}
