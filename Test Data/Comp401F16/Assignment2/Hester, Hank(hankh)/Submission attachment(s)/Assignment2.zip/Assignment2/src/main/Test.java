package main;

public class Test {

	public static void main(String[] args) {
		int num = 0;
		System.out.println();
	}

}
