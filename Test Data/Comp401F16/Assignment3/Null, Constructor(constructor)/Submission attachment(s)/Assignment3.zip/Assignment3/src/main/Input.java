package main;

public interface Input 
{
	public String getInput();
	public void setInput(String s);
}
