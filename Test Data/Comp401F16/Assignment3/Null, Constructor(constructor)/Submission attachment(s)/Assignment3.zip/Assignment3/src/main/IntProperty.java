package main;

public interface IntProperty 
{
	public int getIntProperty();
}
