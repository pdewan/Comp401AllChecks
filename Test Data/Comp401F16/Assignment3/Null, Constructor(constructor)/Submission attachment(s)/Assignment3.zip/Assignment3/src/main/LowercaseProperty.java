package main;

public interface LowercaseProperty 
{
	public String getLowercaseProperty();
}
