package grail.interfaces;
import util.annotations.Tags;

@Tags({"End"})
public interface End extends Token{

}
