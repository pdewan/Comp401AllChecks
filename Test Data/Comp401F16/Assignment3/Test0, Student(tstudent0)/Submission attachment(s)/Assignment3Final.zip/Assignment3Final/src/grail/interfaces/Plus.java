package grail.interfaces;
import util.annotations.Tags;

@Tags({"Plus"})
public interface Plus extends Token{

}
