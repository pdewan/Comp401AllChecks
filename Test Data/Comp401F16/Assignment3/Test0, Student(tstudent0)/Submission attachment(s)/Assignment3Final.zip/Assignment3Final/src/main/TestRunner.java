package main;

import gradingTools.comp401f16.assignment3.testcases.Assignment3Suite;

public class TestRunner {

	public static void main(String[] args) {
		Assignment3Suite.main(args);
	}

}
