package main;

import grader.basics.execution.GradingMode;
import gradingTools.comp401f16.assignment3.testcases.Assignment3Suite;

public class TestRunner {

	public static void main(String[] args) {
//		GradingMode.setGraderRun(true);
		Assignment3Suite.main(args);
	}

}
