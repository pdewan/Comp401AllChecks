package grail.interfaces;
import util.annotations.Tags;

@Tags({"Quote"})
public interface Quote extends Token{

}
