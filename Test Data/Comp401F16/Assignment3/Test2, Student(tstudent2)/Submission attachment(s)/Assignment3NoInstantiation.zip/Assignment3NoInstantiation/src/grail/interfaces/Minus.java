package grail.interfaces;
import util.annotations.Tags;

@Tags({"Minus"})
public interface Minus extends Token{

}
