package main;

import gradingTools.comp401f16.assignment2.testcases.Assignment2Suite;
import grader.basics.execution.GradingMode;

public class TestRunner {

	public static void main(String[] args) {
		GradingMode.setGraderRun(true);
		Assignment2Suite.main(args);
	}

}
