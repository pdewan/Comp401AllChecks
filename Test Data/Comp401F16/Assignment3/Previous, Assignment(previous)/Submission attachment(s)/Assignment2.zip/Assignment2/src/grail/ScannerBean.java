package grail;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

import mp.scanner.ScanningIterator;


/**
 * A "Bean" object whose setter for scannedString prints the tokens and their types.
 * @author Semion
 *
 */
@Tags({"ScannerBean"})
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"ScannedString"})
@EditablePropertyNames({"ScannedString"})
public class ScannerBean {

	String scannedString;
	
	public String getScannedString(){
		return scannedString;
	};
	
	public void setScannedString(String s){
		scanString(s);
		scannedString = s;
	};
	
	/**
	 * Produces output from each string
	 */
	private static void scanString(String s){
		
		ScanningIterator iterator = new ScanningIterator(s);
		
		System.out.println("Tokens:");
		
		while (iterator.hasNext()){
			String token = iterator.next();

			boolean valid = true; // will be used to mark invalid tokens
			
			// Check for number
			if (Character.isDigit(token.charAt(0))){
				valid = isValidNumber(token);
				if (valid){
					System.out.print("number: ");
				}
				
			// Check for word
			} else if (Character.isLetter(token.charAt(0))){
				valid = isValidWord(token);
				if (valid){
					System.out.print("word: ");
				}
			
			// Check for quoted string
			} else if (token.charAt(0) == '\"'){
				
				// The only invalid token would be an empty quoted string
				if (token.length() < 3){
					valid = false;
				}
				
				if (valid){
					
					// Trim quotation marks off the ends of the token
					token = token.substring(1, token.length()-1);
					
					System.out.print("quoted string: ");
				}
			
			// Check for sign
			} else if (token.length() == 1 
					&& (token.charAt(0) == '+' || token.charAt(0) == '-')){
				
				System.out.print("sign: "); // No way to be invalid
			
			// Otherwise invalid
			} else{
				valid = false;
			}
			
			if (!valid){
				System.out.print("INVALID TOKEN: ");
			}
			
			System.out.println(token);
		}//end printing tokens
	}//end scanString()
	
	private static boolean isValidWord(String s){
		
		// Assume correct to begin with
		boolean validity = true;
		
		// Go through and stop at any invalid character
		for (int i = 0; i < s.length(); ++i){
			if (!Character.isLetter(s.charAt(i))){
				validity = false;
				break;
			}
		}
		return validity;
	}
	
	private static boolean isValidNumber(String s){
		
		// Assume correct to begin with
		boolean validity = true;
		
		// Go through and stop at any invalid character
		for (int i = 0; i < s.length(); ++i){
			if (!Character.isDigit(s.charAt(i))){
				validity = false;
				break;
			}
		}
		return validity;
	}
	
}//end class
