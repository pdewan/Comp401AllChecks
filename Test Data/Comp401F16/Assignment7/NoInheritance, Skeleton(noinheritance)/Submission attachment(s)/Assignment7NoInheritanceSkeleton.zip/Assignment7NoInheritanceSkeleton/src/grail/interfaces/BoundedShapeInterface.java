package grail.interfaces;

import util.annotations.Tags;

@Tags({"BoundedShape"})
public interface BoundedShapeInterface {

}
