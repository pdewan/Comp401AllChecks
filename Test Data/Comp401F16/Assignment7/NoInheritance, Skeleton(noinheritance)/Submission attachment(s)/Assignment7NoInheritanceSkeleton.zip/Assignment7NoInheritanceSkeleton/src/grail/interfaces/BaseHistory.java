package grail.interfaces;

public interface BaseHistory {
	
}
