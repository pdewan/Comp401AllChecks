package main;

public interface StringValueToken {
	public String getValue();
}
