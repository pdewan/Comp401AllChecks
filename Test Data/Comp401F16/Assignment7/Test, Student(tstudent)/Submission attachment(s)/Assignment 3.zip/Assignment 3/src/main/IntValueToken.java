package main;

public interface IntValueToken {
	public int getValue();
}
