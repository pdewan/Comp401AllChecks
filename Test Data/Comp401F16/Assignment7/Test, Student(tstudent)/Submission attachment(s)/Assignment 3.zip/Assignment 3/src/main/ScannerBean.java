package main;

public interface ScannerBean {
	public String getScannedString();
	public void setScannedString(String scannedString);
}
