package main;

public interface Token {
	public String getInput();
	public void setInput(String input);
}
