package grail.scanner;

import util.annotations.Tags;

@Tags({"CommandInterpreter"})
public interface CommandInterpreterInterface {

	String getCommand();

	void setCommand(String command);//end setCommand

}