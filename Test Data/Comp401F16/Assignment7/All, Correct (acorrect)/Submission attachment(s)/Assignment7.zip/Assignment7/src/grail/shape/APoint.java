package grail.shape;
import util.annotations.EditablePropertyNames;
import util.annotations.Explanation;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;
import util.annotations.Visible;
@StructurePattern(StructurePatternNames.POINT_PATTERN)
@Visible(false)
@Explanation("Uses Cartesian representation.")
@Tags({"Locatable"})

@PropertyNames({"x","y"})
@EditablePropertyNames({"x","y"})
public class APoint implements Point {	
	protected int x, y;
	public APoint(int theX, int theY) {
		x = theX;
		y = theY;
	}

	public int getX() { return x; }
	public int getY() { return y; }
	public void setX(int newX) {x = newX;}
	public void setY(int newY) {y = newY;}
	
}
