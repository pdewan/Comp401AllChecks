package main;


//import java.util.Scanner;

import grail.shape.Avatar;
import grail.shape.AvatarInterface;
import grail.scanner.BeanStringScanner7;
import grail.scanner.CommandInterpreter;
import grail.scanner.CommandInterpreterInterface;
import grail.shape.BridgeScene;
import grail.shape.BridgeSceneInterface;
import grail.scanner.ScannerInterface;
import bus.uigen.ObjectEditor;
import bus.uigen.OEFrame;
import util.annotations.WebDocuments;
import util.misc.ThreadSupport;

//import lectures.animation.threads_commands.ThreadSupport;
/**
 * 
 * @author Dong Nie
 * dongnie@cs.unc.edu
 *
 *This is for assignment7 from comp 401
 */
public class Assignment7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		final int intervalTime=3000;
		ScannerInterface bss=new BeanStringScanner7();

		 OEFrame scannerEditor = ObjectEditor.edit(bss);
		 bss.setScannedString("MoVe 050 { saY \"hi!\" } ");
		 scannerEditor.refresh();
		 ThreadSupport.sleep(intervalTime);
		 bss.setScannedString("RotateLeftArm 5 rotateLeftArm approach");
		 scannerEditor.refresh();
		 ThreadSupport.sleep(intervalTime); // 3 second delay should be enough
		 bss.setScannedString("Call Define 5 Turnleft ");
		 scannerEditor.refresh();
		 ThreadSupport.sleep(intervalTime); // 3 second delay should be enough
		
		//animate bridge scene
		BridgeSceneInterface bsi=new BridgeScene();
		OEFrame sceneEditor = ObjectEditor.edit(bsi);
		final int width=1000,height=800;
		sceneEditor.setSize(width, height);
		sceneEditor.refresh();
		final int longSleepTime=3000;
		final int shortSleepTime=10;
		ThreadSupport.sleep(longSleepTime);
		
		//animate approach scene
		bsi.approachScene(bsi.getArthur());
		sceneEditor.refresh();
		ThreadSupport.sleep(longSleepTime);
//		
//		//animate say
//		bsi.sayScene("wahaha");
//		oeFrame.refresh();
//		ThreadSupport.sleep(longSleepTime);
//		//animate say
//		bsi.sayScene("nihao");
//		oeFrame.refresh();
//		ThreadSupport.sleep(longSleepTime);
//		
//		//animate pass
//		bsi.passScene();
//		oeFrame.refresh();
//		ThreadSupport.sleep(longSleepTime);
//	
//		//animate approach scene
//		bsi.approachScene(bsi.getGalahad());
//		oeFrame.refresh();
//		ThreadSupport.sleep(longSleepTime);
//		
//		//animate fail
//		bsi.failScene();
//		oeFrame.refresh();
//		ThreadSupport.sleep(longSleepTime);
//
//		
//		//animate scroll
//		bsi.scrollScene(50, 50);
//		oeFrame.refresh();
//		ThreadSupport.sleep(longSleepTime);
		
		
		//animate the command interpreter
		CommandInterpreterInterface cpi=new CommandInterpreter(bsi,bss);
		OEFrame commandEditor = ObjectEditor.edit(cpi);
//		cpi.setCommand("say \"hi\"");
//		commandEditor.refresh();
//		scannerEditor.refresh();
//		sceneEditor.refresh();
//		ThreadSupport.sleep(longSleepTime);
//		
//		cpi.setCommand("Move robin 20 20");
//		commandEditor.refresh();
//		scannerEditor.refresh();
//		sceneEditor.refresh();
//		ThreadSupport.sleep(longSleepTime);
//		
//		
//		cpi.setCommand("Move robin -20 -20");
//		commandEditor.refresh();
//		scannerEditor.refresh();
//		sceneEditor.refresh();
//		ThreadSupport.sleep(longSleepTime);
		
		cpi.setCommand("Move robin ++20 20");
		commandEditor.refresh();
		scannerEditor.refresh();
		sceneEditor.refresh();
		ThreadSupport.sleep(longSleepTime);
	}
}
