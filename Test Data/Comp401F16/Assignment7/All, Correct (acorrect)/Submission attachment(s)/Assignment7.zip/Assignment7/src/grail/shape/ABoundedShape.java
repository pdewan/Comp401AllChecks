package grail.shape;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.Tags;

@Tags({"BoundedShape"})
@PropertyNames({"x","y","width","height"})
@EditablePropertyNames({"x","y","width","height"})
public class ABoundedShape extends APoint implements BoundedShape{
	protected int x, y, width, height;
	
	public ABoundedShape(int x, int y,int width, int height)
	{
		super(x,y);
		this.width=width;
		this.height=height;
	}
	
//	public void setX(int x)
//	{
//		this.x=x;
//	}
//    public void setY(int y)
//    {
//    	this.y=y;
//    }
//    public int getX()
//    {
//    	return this.x;
//    }
//    public int getY()
//    {
//    	return this.y;
//    }
    public int getWidth()
    {
    	return this.width;
    }
    public int getHeight()
    {
    	return this.height;
    }
    public void setWidth(int w)
    {
    	this.width=w;
    }
    public void setHeight(int h)
    {
    	this.height=h;
    }
	
}
