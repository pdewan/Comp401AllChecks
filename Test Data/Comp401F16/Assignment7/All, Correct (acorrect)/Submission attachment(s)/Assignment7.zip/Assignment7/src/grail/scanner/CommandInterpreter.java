package grail.scanner;

import mp.Minus;
import mp.Move;
import mp.Plus;
import mp.QuotedString;
import mp.RawInput;
import mp.Say;
import mp.Word;
import mp.Number;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.Tags;
import util.annotations.Visible;
import grail.ds.Table;
import grail.ds.TableInterface;
import grail.shape.AvatarInterface;
import grail.shape.BridgeScene;
import grail.shape.BridgeSceneInterface;
@PropertyNames({"command","errorCommand"})
@EditablePropertyNames({"command"})
@Tags({"Command Interpreter","SignedMove","ErrorResilient"})
public class CommandInterpreter implements CommandInterpreterInterface{
	private TableInterface table = new Table();
	private BridgeSceneInterface briScene;
	private ScannerInterface beanScanner;
	private String errorCommand="";
	private String command="";
	private int currIndex=0;
	
	public CommandInterpreter(BridgeSceneInterface bsi, ScannerInterface si)
	{
		briScene=bsi;
		beanScanner=si;
		
		table.put("arthur",briScene.getArthur());
		table.put("lancelot",briScene.getLancelot());
		table.put("robin",briScene.getRobin());
		table.put("galahad",briScene.getGalahad());
		table.put("guard",briScene.getGuard());
	}
	
	public CommandInterpreter()
	{
		
	}
	@Visible (false)
	public ScannerInterface getBeanScanner()
	{
		return this.beanScanner;
	}
	
	@Visible (false)
	public BridgeSceneInterface getBriScene()
	{
		return this.briScene;
	}
	
	public void setCommand(String str)
	{
		this.command=str;
		currIndex=0;
		this.errorCommand="";
		parseTokens(str);
	}
	
	private void parseTokens(String line)
	{
		this.beanScanner.setScannedString(line);
		RawInput[] tokens=this.beanScanner.getCompactTokenArray();//get the tokens

		currIndex=0;
		if (tokens[currIndex] instanceof Say)
		{
			currIndex+=1;
			if (tokens[currIndex] instanceof QuotedString)
			{
				this.briScene.sayScene(tokens[currIndex].getInput());//not have to indicate which to say
			}else
			{
				System.out.println("command not following the format");
				this.errorCommand="unexpected command: "+tokens[currIndex]+"\t and the expected one is QuotedString";
			}
		}else if (tokens[currIndex] instanceof Move)
		{
			currIndex+=1;
			if(tokens[currIndex] instanceof Word)
			{
				AvatarInterface currAvatar=(AvatarInterface)table.get(tokens[currIndex].getInput().toLowerCase());
				if (currAvatar!=null)
				{
					currIndex+=1;
					//go on to read
					int firstSign=1;
					if (tokens[currIndex] instanceof Number)
					{
						firstSign=1;
						parse2Numbers(currAvatar, tokens, firstSign);
					}
					else if(tokens[currIndex] instanceof Plus)
					{
						currIndex+=1;
						firstSign=1;

						if (tokens[currIndex] instanceof Number)
						{
							parse2Numbers(currAvatar, tokens, firstSign);
						}
						else
						{
							System.out.println("command not following the format");
							this.errorCommand="unexpected command: "+tokens[currIndex]+"\t and the expected one is Number";
						}
					}
					else if (tokens[currIndex] instanceof Minus)
					{
						currIndex+=1;
						firstSign=-1;
						if (tokens[currIndex] instanceof Number)
						{
							parse2Numbers(currAvatar, tokens, firstSign);
						}
						else
						{
							System.out.println("command not following the format");
							this.errorCommand="unexpected command: "+tokens[currIndex]+"\t and the expected one is Number";
						}
					}
					else 
					{
						System.out.println("command not following the format");
						this.errorCommand="unexpected command: "+tokens[currIndex]+"\t and the expected one is Number or Sign";
					}
				}
				else
				{
					System.out.println("command not following the format");
					this.errorCommand="unexpected command: "+tokens[currIndex]+"\t and the expected one is one of the five Avatar names";
				}
			}
		}
		
	}
	
	//parse the two numbers following move commands, we are supposed to have processed the first Number(including the +/-),
	//and the current index goes to this first number
	private void parse2Numbers(AvatarInterface currAvatar, RawInput[] tokens, int firstSign)
	{

		int num1=Integer.parseInt(tokens[currIndex].getInput());
		num1*=firstSign;
		int num2=0;
		currIndex+=1;
		if (tokens[currIndex] instanceof Number)
		{
			num2=Integer.parseInt(tokens[currIndex].getInput());
			currAvatar.move(num1,num2);
		}else if(tokens[currIndex] instanceof Plus)
		{
			currIndex+=1;
			if (tokens[currIndex] instanceof Number)
			{
				currAvatar.move(num1,Integer.parseInt(tokens[currIndex].getInput()));
			}
			else
			{
				System.out.println("command not following the format");
				this.errorCommand="unexpected command: "+tokens[currIndex]+"\t and the expected one is Number";
			}
		}else if(tokens[currIndex] instanceof Minus)
		{
			currIndex+=1;
			if (tokens[currIndex] instanceof Number)
			{
				num2=Integer.parseInt(tokens[currIndex].getInput());
				num2=-1*num2;
				currAvatar.move(num1,num2);
			}
			else
			{
				System.out.println("command not following the format");
				this.errorCommand="unexpected command: "+tokens[currIndex]+"\t and the expected one is Number";
			}
		}
			
	
	}
	
	public String getErrorCommand()
	{
		return this.errorCommand;
	}
	public String getCommand()
	{
		return this.command;
	}
}