package grail.mvc.view;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.beans.PropertyChangeEvent;

import grail.interfaces.AvatarInterface;
import grail.interfaces.mvc.PaintingViewMaster;
import grail.interfaces.mvc.PaintingViewModule;
import util.annotations.Tags;

@Tags({"PaintListener"})
public class AvatarView implements PaintingViewModule{

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void paint(Graphics2D g) {
		// TODO Auto-generated method stub
		
	}
	
}
