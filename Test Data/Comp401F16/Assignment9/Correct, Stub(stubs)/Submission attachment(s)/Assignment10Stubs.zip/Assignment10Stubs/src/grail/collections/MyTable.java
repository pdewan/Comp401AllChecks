package grail.collections;

import java.util.ArrayList;
import java.util.List;

import grail.interfaces.Table;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@StructurePattern(StructurePatternNames.MAP_PATTERN)
@Tags({"Table"})
public class MyTable implements Table {

	@Override
	public void put(String key, Object val) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object get(String key) {
		// TODO Auto-generated method stub
		return null;
	}
	
}//end class
