package grail.animations;

import grail.interfaces.AnimatorInterface;
import grail.interfaces.AvatarInterface;
import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.RotatingLineInterface;
import util.annotations.Tags;
import util.misc.ThreadSupport;


@Tags({"Animator"})
public class Animator implements AnimatorInterface {

	
}
