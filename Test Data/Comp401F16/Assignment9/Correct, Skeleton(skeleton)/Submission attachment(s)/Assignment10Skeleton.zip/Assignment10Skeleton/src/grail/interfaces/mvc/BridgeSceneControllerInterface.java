package grail.interfaces.mvc;

import java.awt.event.KeyListener;
import java.awt.event.MouseListener;

import util.annotations.Tags;

@Tags({"BridgeSceneController"})
public interface BridgeSceneControllerInterface {

}
