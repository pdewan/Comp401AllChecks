package grail.interfaces;

import util.annotations.Tags;

public interface AnimatorInterface {
	
}
