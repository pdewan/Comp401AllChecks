package grail.animations;

import grail.interfaces.AnimatorInterface;
import grail.interfaces.AvatarInterface;
import grail.interfaces.CommandThread;
import util.annotations.Tags;

@Tags({"AnimatingCommand"})
public class AnimatingCommand implements CommandThread{

}
