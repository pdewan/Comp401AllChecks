package grail.mvc.controller;

import java.awt.Component;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import grail.SingletonsCreator;
import grail.interfaces.AvatarInterface;
import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.mvc.BridgeSceneControllerInterface;
import grail.interfaces.mvc.PaintingViewMaster;
import util.annotations.Tags;

@Tags({"BridgeSceneController"})
public class BridgeSceneController implements BridgeSceneControllerInterface{
	
}
