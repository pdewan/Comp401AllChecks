package grail.interfaces;

import java.beans.PropertyChangeListener;

import util.annotations.Tags;

@Tags({"Avatar", "move"})
public interface AvatarInterface extends Locatable{

}
