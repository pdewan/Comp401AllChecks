package grail.animations;

import grail.interfaces.AnimatorInterface;
import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.CommandThread;

public class ClapCommand implements CommandThread{


}
