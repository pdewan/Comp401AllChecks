package grail.interfaces;

public interface CommandThread {

}
