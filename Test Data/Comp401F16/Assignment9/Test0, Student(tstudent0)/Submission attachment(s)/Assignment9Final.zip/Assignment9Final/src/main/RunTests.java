package main;

import gradingTools.comp401f16.assignment9.testcases.Assignment9Suite;

public class RunTests {

	public static void main(String[] args) {
		Assignment9Suite.main(args);
	}

}
