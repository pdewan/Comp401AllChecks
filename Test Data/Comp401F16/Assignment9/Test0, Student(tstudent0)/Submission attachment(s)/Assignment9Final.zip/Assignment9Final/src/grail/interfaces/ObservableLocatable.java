package grail.interfaces;

import util.models.PropertyListenerRegisterer;

public interface ObservableLocatable extends Locatable, PropertyListenerRegisterer{

}
