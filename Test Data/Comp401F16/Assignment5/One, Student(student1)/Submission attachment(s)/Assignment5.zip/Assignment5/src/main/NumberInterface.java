package main;

public interface NumberInterface {
  public int getValue();

}
