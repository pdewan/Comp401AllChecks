package grail.shapes;

public interface AllFiveGuysInterface {
  public AvatarClass getGuard();
  public AvatarClass getArthur();
  public AvatarClass getLancelot();
  public AvatarClass getRobin();
  public AvatarClass getGalahad();
}
