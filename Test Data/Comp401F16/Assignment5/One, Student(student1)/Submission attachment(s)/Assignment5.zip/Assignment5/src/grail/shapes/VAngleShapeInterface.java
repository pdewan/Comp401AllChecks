package grail.shapes;

public interface VAngleShapeInterface {
  public LineClass getLeftLine();
  public LineClass getRightLine();
  public void moveVShape(Point pointTheLinesMeet, int movedX, int movedY);
}
