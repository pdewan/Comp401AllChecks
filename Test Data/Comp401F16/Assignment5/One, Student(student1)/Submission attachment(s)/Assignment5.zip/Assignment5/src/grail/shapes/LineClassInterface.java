package grail.shapes;

public interface LineClassInterface {
  public Point getLocation();
  public void setLocation(Point newLocation);
  public int getWidth();
  public void setWidth(int newY);
  public int getHeight();
  public void setHeight(int newLength);
  
  
}
