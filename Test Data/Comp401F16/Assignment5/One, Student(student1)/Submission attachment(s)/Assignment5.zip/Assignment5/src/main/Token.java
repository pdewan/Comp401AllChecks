package main;

public interface Token {
  public void setInput(String scannedString);

  public String getInput();

}
