package main;

public interface WordInterface {

  public String getValue();

}
