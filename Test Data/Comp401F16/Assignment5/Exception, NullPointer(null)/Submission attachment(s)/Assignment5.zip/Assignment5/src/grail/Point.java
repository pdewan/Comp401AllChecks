package grail;

public interface Point {
	 public int getX();
	 public int getY();
	 public double getAngle();
	 public double getRadius();
}