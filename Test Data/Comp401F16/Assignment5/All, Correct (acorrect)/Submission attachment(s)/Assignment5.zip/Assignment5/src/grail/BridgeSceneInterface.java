package grail;

public interface BridgeSceneInterface {
	public AvatarInterface getArthur();
	public AvatarInterface getLancelot();
	public AvatarInterface getRobin();
	public AvatarInterface getGalahad();
	public AvatarInterface getGuard();
}
