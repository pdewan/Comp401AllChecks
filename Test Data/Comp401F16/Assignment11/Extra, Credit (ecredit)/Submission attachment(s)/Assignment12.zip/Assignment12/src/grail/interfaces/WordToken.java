package grail.interfaces;

public interface WordToken extends StoreToken {
	public String getValue();
}
