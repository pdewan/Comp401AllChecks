package grail.demo;

import util.models.PropertyListenerRegisterer;

public interface Demo extends PropertyListenerRegisterer{
	public void run();
}
