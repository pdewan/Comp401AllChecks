package grail.demo;

import util.models.PropertyListenerRegisterer;

public interface TwelveDemo extends PropertyListenerRegisterer, Demo{

}
