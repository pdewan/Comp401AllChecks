package grail.helpers;


public interface ClearanceManager {
	public void proceed();
	public void proceedAll();
	public void waitForProceed();
}
