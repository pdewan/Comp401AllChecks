package grail.interfaces;

public interface CommandToken extends WordToken{

}
