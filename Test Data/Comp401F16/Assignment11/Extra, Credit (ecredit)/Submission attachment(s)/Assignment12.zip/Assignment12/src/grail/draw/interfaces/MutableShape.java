package grail.draw.interfaces;

public interface MutableShape extends Shape {
    public void setHeight(int newHeight);
    public void setWidth(int newWidth);

}
