package grail.scanner.commands;

import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.CommandThread;
import util.annotations.Tags;

@Tags({"FailCommand"})
public class FailCommand implements CommandThread{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
}
