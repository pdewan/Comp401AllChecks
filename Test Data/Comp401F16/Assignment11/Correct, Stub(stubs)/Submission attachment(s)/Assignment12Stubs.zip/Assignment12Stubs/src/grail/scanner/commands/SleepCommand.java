package grail.scanner.commands;

import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.CommandThread;
import util.annotations.Tags;
import util.misc.ThreadSupport;

@Tags({"SleepCommandObject"})
public class SleepCommand implements CommandThread{
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
