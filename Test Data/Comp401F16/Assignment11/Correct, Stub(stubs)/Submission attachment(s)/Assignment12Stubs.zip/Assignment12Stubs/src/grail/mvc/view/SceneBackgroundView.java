package grail.mvc.view;

import java.awt.Graphics2D;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.mvc.PaintListener;
import grail.interfaces.mvc.PaintingViewMaster;
import util.annotations.Tags;

@Tags({"PaintListener"})
public class SceneBackgroundView implements PaintListener{

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void paint(Graphics2D g) {
		// TODO Auto-generated method stub
		
	}

	
}
