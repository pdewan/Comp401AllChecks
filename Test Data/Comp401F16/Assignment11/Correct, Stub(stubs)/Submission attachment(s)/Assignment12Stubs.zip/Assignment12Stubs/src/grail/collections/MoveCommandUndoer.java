package grail.collections;

import java.util.ArrayList;
import java.util.List;

import grail.interfaces.CommandThread;
import grail.interfaces.UndoableCommandThread;
import grail.interfaces.Undoer;
import grail.scanner.commands.MoveCommand;

public class MoveCommandUndoer implements Undoer {

	@Override
	public void execute(UndoableCommandThread c) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void redo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}


}
