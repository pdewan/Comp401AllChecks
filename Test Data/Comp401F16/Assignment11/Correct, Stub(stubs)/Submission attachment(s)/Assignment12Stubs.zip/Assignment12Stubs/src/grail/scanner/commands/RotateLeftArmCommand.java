package grail.scanner.commands;

import grail.interfaces.AvatarInterface;
import grail.interfaces.CommandThread;
import util.annotations.Tags;

@Tags({"RotateLeftArmCommandObject"})
public class RotateLeftArmCommand implements CommandThread {
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
}
