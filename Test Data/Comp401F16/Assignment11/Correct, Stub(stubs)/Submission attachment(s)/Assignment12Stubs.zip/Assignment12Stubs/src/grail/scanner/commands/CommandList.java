package grail.scanner.commands;

import java.util.ArrayList;
import java.util.List;

import grail.interfaces.CompositeCommandThread;
import util.annotations.Tags;

@Tags({"CommandList"})
public class CommandList implements CompositeCommandThread{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void add(Runnable r) {
		// TODO Auto-generated method stub
		
	}

}
