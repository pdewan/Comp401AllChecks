package mp.tokens;

public interface RawInput {
	public void setInput(String input);
	public String getInput();
}
