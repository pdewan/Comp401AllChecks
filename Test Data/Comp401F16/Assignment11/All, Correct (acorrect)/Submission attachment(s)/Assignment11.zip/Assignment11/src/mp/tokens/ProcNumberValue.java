package mp.tokens;

public interface ProcNumberValue {
	public int getValue();
}
