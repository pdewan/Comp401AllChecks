package grail.view;

import java.beans.PropertyChangeListener;

public interface ConsoleSceneView extends PropertyChangeListener {

}
