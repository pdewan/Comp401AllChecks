package grail.controller;

import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JTextField;

public interface CommandInterpreterController {
	public JMenuItem getMenuItem() ;public JButton getButton();
	public JTextField getTextField();
}
