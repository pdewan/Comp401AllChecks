package mp.tokens;

public interface ProcWordValue {
	public String getValue();
}
