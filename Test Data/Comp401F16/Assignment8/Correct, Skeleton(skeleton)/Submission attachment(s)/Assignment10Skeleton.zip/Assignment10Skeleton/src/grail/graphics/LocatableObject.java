package grail.graphics;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;

import grail.interfaces.Locatable;

public class LocatableObject implements Locatable{


}
