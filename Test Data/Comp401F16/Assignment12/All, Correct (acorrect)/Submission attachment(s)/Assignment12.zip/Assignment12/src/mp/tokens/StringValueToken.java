package mp.tokens;

public interface StringValueToken extends Token{
	public String getValue();
}
