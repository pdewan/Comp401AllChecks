package mp.commands;

import mp.tokens.WordToken;
import util.annotations.Tags;

@Tags({"fail"})
public class FailCommand extends WordToken{
	public FailCommand(String input) {
		super(input);
		// TODO Auto-generated constructor stub
	}
}
