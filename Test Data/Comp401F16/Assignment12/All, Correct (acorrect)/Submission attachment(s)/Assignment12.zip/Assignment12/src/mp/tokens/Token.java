package mp.tokens;

public interface Token {
	public String getInput();
	public void setInput(String input);
}
