package mp.commands;

import mp.tokens.WordToken;

public class ApproachCommand extends WordToken{
	public ApproachCommand(String input){
		super(input);
	}
}
