package mp.painter;

public interface BridgeScenePainter {
	public void addPaintListener(PaintListener listener);
}
