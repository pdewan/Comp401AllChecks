package mp.helpers;

public interface BroadcastingClearanceManager extends ClearanceManager {
	public void proceedAll();

}
