package mp.painter;

public interface BackgroundPaintListener extends PaintListener{

}
