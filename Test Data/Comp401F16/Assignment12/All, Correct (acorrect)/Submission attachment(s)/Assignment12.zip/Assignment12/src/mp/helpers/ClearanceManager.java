package mp.helpers;

public interface ClearanceManager {
	public void proceed();
	public void waitForProceed();	
	

}
