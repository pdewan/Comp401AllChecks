package mp.painter;

public interface AreaPaintListener extends PaintListener{

}
