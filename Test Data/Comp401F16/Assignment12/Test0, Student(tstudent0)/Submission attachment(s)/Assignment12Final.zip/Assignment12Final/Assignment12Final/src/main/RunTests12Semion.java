package main;

import gradingTools.comp401f16.assignment12.testcases.Assignment12Suite;


public class RunTests12Semion {
	public static void main (String[] args) {
		Assignment12Suite.main(args);
	}

}
