package grail.animations.fromJavaTeaching;

public interface BroadcastingClearanceManager extends ClearanceManager {
	public void proceedAll();

}
