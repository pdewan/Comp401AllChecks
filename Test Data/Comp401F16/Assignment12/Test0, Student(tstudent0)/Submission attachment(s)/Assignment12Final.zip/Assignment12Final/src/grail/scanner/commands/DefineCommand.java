package grail.scanner.commands;

import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.CommandThread;
import grail.interfaces.Table;
import util.annotations.Tags;
import util.misc.ThreadSupport;

@Tags({"DefineCommandObject"})
public class DefineCommand implements CommandThread{

	private String name;
	private CommandThread body;
	private Table<CommandThread> environment;
	
	public DefineCommand(String name, CommandThread body, Table<CommandThread> environment){
		this.name = name;
		this.body = body;
		this.environment = environment;
	}
	
	@Override
	public void run() {
		environment.put(name, body);
	}

}
