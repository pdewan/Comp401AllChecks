package grail.scanner;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;

import grail.SingletonsCreator;
import grail.animations.AnimatingCommand;
import grail.animations.SleepBasedAnimator;
import grail.animations.WaitBasedAnimator;
import grail.animations.ClapCommand;
import grail.animations.ClapLockstepCommand;
import grail.animations.LockstepAnimatingCommand;
import grail.animations.fromJavaTeaching.ABroadcastingClearanceManager;
import grail.animations.fromJavaTeaching.BroadcastingClearanceManager;
import grail.interfaces.AnimatorInterface;
import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.CommandInterpreterInterface;
import grail.interfaces.CommandThread;
import grail.interfaces.ScannerBeanInterface;
import grail.interfaces.Table;
import grail.interfaces.Undoer;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;
import grail.interfaces.ParserInterface;

@Tags({"CommandInterpreter", "SignedMoveCommandInterpreter", "ErrorResilientCommandInterpreter","ObservableCommandInterpreter"})
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Command", "Errors"})
@EditablePropertyNames({"Command"})
public class CommandInterpreter implements CommandInterpreterInterface {

	private List<PropertyChangeListener> listeners = new ArrayList<PropertyChangeListener>();
	
	// Key references
	private ScannerBeanInterface scannerBean;
	private BridgeSceneInterface scene;
	private ParserInterface parser;
	private BroadcastingClearanceManager clearanceManager;
	
	// Required table
	private Table avatars;
	
	// fields that back properties
	private String command ="";
	private String errorString = "";
	
	// Avatar-specific animators
	AnimatorInterface arthurAnimator = new SleepBasedAnimator();
	AnimatorInterface robinAnimator = new SleepBasedAnimator();
	AnimatorInterface galahadAnimator = new SleepBasedAnimator();
	AnimatorInterface lancelotAnimator = new SleepBasedAnimator();
	AnimatorInterface guardAnimator = new SleepBasedAnimator();
	
	// Lockstep animators
	AnimatorInterface arthurLockstepAnimator = new WaitBasedAnimator();
	AnimatorInterface robinLockstepAnimator = new WaitBasedAnimator();
	AnimatorInterface galahadLockstepAnimator = new WaitBasedAnimator();
	AnimatorInterface lancelotLockstepAnimator = new WaitBasedAnimator();
	
	// Constructor
	public CommandInterpreter(BridgeSceneInterface scene, ScannerBeanInterface scannerBean){
		this.scannerBean = scannerBean;
		this.scene = scene;
		parser = SingletonsCreator.parserFactoryMethod();
		avatars = SingletonsCreator.avatarTableFactoryMethod();
		clearanceManager = new ABroadcastingClearanceManager();
	}
	
	@Override
	public String getCommand(){
		return command;
	}
	
	@Override
	public void setCommand(String command){
		String oldCommand = this.command;
		this.command = command;
		parser.setCommandText(command);
		
		String oldErrorString = errorString;
		errorString = parser.getErrors();
		notifyAllListeners("Errors", oldErrorString, errorString);
		notifyAllListeners("Command", oldCommand, command);
		
		// Execute the command
		CommandThread commandThread = parser.getCommandObject();
		commandThread.run();
	}//end setCommand

	@Override
	public String getErrors() {
		return errorString;
	}

	@Override
	public void addPropertyChangeListener(PropertyChangeListener listener) {
		listeners.add(listener);
	}
	
	private void notifyAllListeners(String propertyName, Object oldValue, Object newValue){
		for (PropertyChangeListener listener : listeners){
			listener.propertyChange(new PropertyChangeEvent(this, propertyName, oldValue, newValue));
		}
	}

	@Override
	@Tags({"asynchronousArthur"})
	public void animateArthur() {
		Thread thread = new Thread(new AnimatingCommand(arthurAnimator, scene.getArthur()));
		thread.start();
	}

	@Tags({"asynchronousGalahad"})
	@Override
	public void animateGalahad() {
		Thread thread = new Thread(new AnimatingCommand(galahadAnimator, scene.getGalahad()));
		thread.start();
	}

	@Tags({"asynchronousLancelot"})
	@Override
	public void animateLancelot() {
		Thread thread = new Thread(new AnimatingCommand(lancelotAnimator, scene.getLancelot()));
		thread.start();
	}

	@Override
	@Tags({"asynchronousRobin"})
	public void animateRobin() {
		Thread thread = new Thread(new AnimatingCommand(robinAnimator, scene.getRobin()));
		thread.start();
	}
	
	@Override
	@Tags({"asynchronousGuard"})
	public void clapGuard(){
		Thread thread = new Thread(new ClapCommand(guardAnimator, scene));
		thread.start();
	}
	
	@Override
	@Tags({"waitingArthur"})
	public void animateArthurWithWait() {
		Thread thread = new Thread(new AnimatingCommand(arthurAnimator, scene.getArthur(), true));
		thread.start();
	}

	@Tags({"waitingGalahad"})
	@Override
	public void animateGalahadWithWait() {
		Thread thread = new Thread(new AnimatingCommand(galahadAnimator, scene.getGalahad(), true));
		thread.start();
	}

	@Tags({"waitingLancelot"})
	@Override
	public void animateLancelotWithWait() {
		Thread thread = new Thread(new AnimatingCommand(lancelotAnimator, scene.getLancelot(), true));
		thread.start();
	}

	@Override
	@Tags({"waitingRobin"})
	public void animateRobinWithWait() {
		Thread thread = new Thread(new AnimatingCommand(robinAnimator, scene.getRobin(), true));
		thread.start();
	}
	
	@Tags({"startAnimation"})
	@Override
	public void startAnimation() {
		clearanceManager.proceedAll();
	}

	@Override
	public void animateArthurWithLockstep() {
		Thread thread = new Thread(new LockstepAnimatingCommand(arthurLockstepAnimator, scene.getArthur()));
		thread.start();
	}

	@Override
	public void animateGalahadWithLockstep() {
		Thread thread = new Thread(new LockstepAnimatingCommand(galahadLockstepAnimator, scene.getGalahad()));
		thread.start();
	}

	@Override
	public void animateLancelotWithLockstep() {
		Thread thread = new Thread(new LockstepAnimatingCommand(lancelotLockstepAnimator, scene.getLancelot()));
		thread.start();
	}

	@Override
	public void animateRobinWithLockstep() {
		Thread thread = new Thread(new LockstepAnimatingCommand(robinLockstepAnimator, scene.getRobin()));
		thread.start();
	}
	
	/**
	 * Moves any lockstep methods forward a step.
	 */
	@Override
	@Tags({"clapGuardLockstep"})
	public void clapGuardLockstep(){
		Thread thread = new Thread(new ClapLockstepCommand(guardAnimator, scene));
		thread.start();
	}
}
