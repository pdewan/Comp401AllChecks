package grail;

import mp.Avatar;

public interface AvatarAnimator {
	public void walk (Avatar anAvatar);
	public void walk (Avatar anAvatar, int finalX, int finalY);
}
