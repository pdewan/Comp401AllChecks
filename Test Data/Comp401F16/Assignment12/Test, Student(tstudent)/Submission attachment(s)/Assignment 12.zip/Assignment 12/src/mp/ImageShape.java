package mp;
//import util.models.PropertyListenerRegisterer;
public interface ImageShape extends BoundedShape{
    public String getImageFileName() ;  
    public void setImageFileName(String newVal);
}
