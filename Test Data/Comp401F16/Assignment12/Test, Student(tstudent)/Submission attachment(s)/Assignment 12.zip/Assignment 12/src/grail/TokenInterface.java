package grail;

public interface TokenInterface {
	public String getInput();
	public void setInput(String newString);
}
