package grail;

public interface ExecutableSay extends Runnable {}
