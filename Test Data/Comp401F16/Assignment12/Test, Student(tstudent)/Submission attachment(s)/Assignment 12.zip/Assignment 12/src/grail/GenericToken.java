package grail;

public class GenericToken implements TokenInterface{
	String input = "";
	public String getInput() {return input;}
	public void setInput(String newInput) {input=newInput;}
}
