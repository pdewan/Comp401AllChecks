package grail;

public interface NumberInterface extends TokenInterface{
	public int getValue();
}
