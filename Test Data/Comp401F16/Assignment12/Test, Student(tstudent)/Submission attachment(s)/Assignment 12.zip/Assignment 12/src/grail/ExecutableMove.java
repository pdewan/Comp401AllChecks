package grail;

public interface ExecutableMove extends Runnable{}
