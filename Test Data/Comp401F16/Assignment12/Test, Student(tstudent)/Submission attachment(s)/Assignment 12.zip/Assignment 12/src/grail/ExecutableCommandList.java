package grail;

public interface ExecutableCommandList extends Runnable{
	public void add (Runnable token);
}
