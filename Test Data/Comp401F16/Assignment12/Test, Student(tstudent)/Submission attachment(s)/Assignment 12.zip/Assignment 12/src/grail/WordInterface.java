package grail;

public interface WordInterface extends TokenInterface{
	public String getValue();
}
