package grail;

public interface CommandList {

}
