package grail;

public interface ExecutableFail extends Runnable{}
