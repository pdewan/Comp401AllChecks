package grail;

public interface ExecutablePass extends Runnable{

}
