package grail;

public interface AnimatingCommand extends Runnable{}
