package main;

import java.beans.PropertyChangeListener;

public interface CommandInterpreterView extends PropertyChangeListener{

}
