package main;

import java.beans.PropertyChangeEvent;
import util.annotations.Tags;
import mp.BridgeScene;
@Tags({"ConsoleSceneView"})

public class AConsoleSceneView implements ConsoleSceneView{
	
	public AConsoleSceneView(BridgeScene aBridgeScene) {
//		aBridgeScene.addPropertyChangeListener(this);
//		
//		aBridgeScene.getArthur().getArms().getLeftLine().addPropertyChangeListener(this);
//		aBridgeScene.getArthur().getArms().getRightLine().addPropertyChangeListener(this);
//		aBridgeScene.getArthur().getHead().addPropertyChangeListener(this);
//		aBridgeScene.getArthur().getLegs().getLeftLine().addPropertyChangeListener(this);
//		aBridgeScene.getArthur().getSword().getSword().addPropertyChangeListener(this);
//		aBridgeScene.getArthur().getText().addPropertyChangeListener(this);
//		aBridgeScene.getArthur().getTorso().getTorso().addPropertyChangeListener(this);
//		
//		aBridgeScene.getGalahad().getArms().getLeftLine().addPropertyChangeListener(this);
//		aBridgeScene.getGalahad().getArms().getRightLine().addPropertyChangeListener(this);
//		aBridgeScene.getGalahad().getHead().addPropertyChangeListener(this);
//		aBridgeScene.getGalahad().getLegs().getLeftLine().addPropertyChangeListener(this);
//		aBridgeScene.getGalahad().getSword().getSword().addPropertyChangeListener(this);
//		aBridgeScene.getGalahad().getText().addPropertyChangeListener(this);
//		aBridgeScene.getGalahad().getTorso().getTorso().addPropertyChangeListener(this);
//		
//		aBridgeScene.getGuard().getArms().getLeftLine().addPropertyChangeListener(this);
//		aBridgeScene.getGuard().getArms().getRightLine().addPropertyChangeListener(this);
//		aBridgeScene.getGuard().getHead().addPropertyChangeListener(this);
//		aBridgeScene.getGuard().getLegs().getLeftLine().addPropertyChangeListener(this);
//		aBridgeScene.getGuard().getSword().getSword().addPropertyChangeListener(this);
//		aBridgeScene.getGuard().getText().addPropertyChangeListener(this);
//		aBridgeScene.getGuard().getTorso().getTorso().addPropertyChangeListener(this);
//		
//		aBridgeScene.getLancelot().getArms().getLeftLine().addPropertyChangeListener(this);
//		aBridgeScene.getLancelot().getArms().getRightLine().addPropertyChangeListener(this);
//		aBridgeScene.getLancelot().getHead().addPropertyChangeListener(this);
//		aBridgeScene.getLancelot().getLegs().getLeftLine().addPropertyChangeListener(this);
//		aBridgeScene.getLancelot().getSword().getSword().addPropertyChangeListener(this);
//		aBridgeScene.getLancelot().getText().addPropertyChangeListener(this);
//		aBridgeScene.getLancelot().getTorso().getTorso().addPropertyChangeListener(this);
//		
//		aBridgeScene.getRobin().getArms().getLeftLine().addPropertyChangeListener(this);
//		aBridgeScene.getRobin().getArms().getRightLine().addPropertyChangeListener(this);
//		aBridgeScene.getRobin().getHead().addPropertyChangeListener(this);
//		aBridgeScene.getRobin().getLegs().getLeftLine().addPropertyChangeListener(this);
//		aBridgeScene.getRobin().getSword().getSword().addPropertyChangeListener(this);
//		aBridgeScene.getRobin().getText().addPropertyChangeListener(this);
//		aBridgeScene.getRobin().getTorso().getTorso().addPropertyChangeListener(this);
//		
//		aBridgeScene.getGorge().getLeftBank().addPropertyChangeListener(this);
//		aBridgeScene.getGorge().getRightBank().addPropertyChangeListener(this);
//		aBridgeScene.getGorge().getTopBridge().addPropertyChangeListener(this);
//		aBridgeScene.getGorge().getBottomBridge().addPropertyChangeListener(this);
//		
//		aBridgeScene.getGuardArea().addPropertyChangeListener(this);
//		aBridgeScene.getKnightArea().addPropertyChangeListener(this);
	}
	
	public void propertyChange(PropertyChangeEvent event) {

	}
	
	
}
