package mp;

public interface StringShape extends Locatable{
    public String getText() ;  
    public void setText(String newVal); 
}


