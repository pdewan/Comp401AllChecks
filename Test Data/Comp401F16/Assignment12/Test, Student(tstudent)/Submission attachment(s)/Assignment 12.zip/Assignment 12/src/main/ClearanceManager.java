package main;

public interface ClearanceManager {
	public void proceed();
	public void waitForProceed();	
	

}
