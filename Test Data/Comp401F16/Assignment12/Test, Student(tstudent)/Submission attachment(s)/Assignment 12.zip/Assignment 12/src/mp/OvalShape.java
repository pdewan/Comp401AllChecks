package mp;

public interface OvalShape extends BoundedShape{}
