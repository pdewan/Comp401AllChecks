package grail;

public interface ExecutableApproach extends Runnable{}
