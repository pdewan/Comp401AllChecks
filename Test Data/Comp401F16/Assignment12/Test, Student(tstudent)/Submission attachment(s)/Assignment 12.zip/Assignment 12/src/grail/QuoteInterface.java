package grail;

public interface QuoteInterface extends TokenInterface {
	public String getValue();
}
