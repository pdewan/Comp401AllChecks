package main;

import java.beans.PropertyChangeListener;
import util.annotations.Tags;
@Tags({"ConsoleSceneView"})

public interface ConsoleSceneView extends PropertyChangeListener{}
