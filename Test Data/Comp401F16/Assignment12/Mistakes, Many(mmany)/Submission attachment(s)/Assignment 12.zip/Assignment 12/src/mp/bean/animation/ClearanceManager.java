package mp.bean.animation;

public interface ClearanceManager {
	public void proceed();
	public void waitForProceed();	
	

}
