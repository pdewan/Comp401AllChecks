package mp.bean.animation;

public interface BroadcastingClearanceManager extends ClearanceManager {
	public void proceedAll();

}
