package main;

import gradingTools.comp401f16.assignment4.testcases.Assignment4Suite;

public class RunTests {

	public static void main(String[] args) {
		Assignment4Suite.main(args);

	}

}
