package grail;

import util.annotations.Tags;
@Tags({"BridgeScene"})

public class BridgeScene implements BridgeSceneInterface{
//Arthur, Lancelot, Robin, Galahad, and Guard
	AvatarInterface arthur;
	AvatarInterface lancelot;
	AvatarInterface robin;
	AvatarInterface galahad;
	AvatarInterface guard;
	ParallelLinesInterface bridge;
	ParallelLinesInterface gorge;
	Shape knightArea,guardArea;
	private boolean occupied;
	AvatarInterface standKnight;
	boolean knightTurn;
	
	public BridgeScene()
	{
		knightTurn=false;
		occupied=false;
		standKnight=null;
		String path="images/";
		arthur=new Avatar("Arthur",path+"arthur.jpg",200,300);
		lancelot=new Avatar("Lancelot",path+"lancelot.jpg",100,300);
		robin=new Avatar("Robin",path+"robin.jpg",200,100);
		galahad=new Avatar("Galahad",path+"galahad.jpg",100,100);
		guard=new Avatar("Guard",path+"guard.jpg",520,250);
		gorge=new Gorge(800,20,600,20);
		bridge=new Bridge(600,300,600,350);
		knightArea=new StandArea(300,300);
		guardArea=new StandArea(500,300);
	}
	
	
	
	@Tags({"approach"})
	public void approachScene(AvatarInterface person)
	{
		//define destination coordinates
		if (!this.occupied)
		{
			standKnight=person;
			final int x=330,y=250;
			final int dx=x-person.getAvatarLocation().getX();
			final int dy=y-person.getAvatarLocation().getY();
			person.move(dx, dy);
			this.occupied=true;
		}else
		{
			System.out.println("the knight area is occupied");
		}
	}
	
	@Tags({"say"})
	public void sayScene(String word)
	{
		if (this.occupied)
		{
			if (knightTurn)
			{
				this.standKnight.getText().setText(word);
			}else
			{
				this.guard.getText().setText(word);
			}
			knightTurn=!knightTurn;
		}
		else
		{
			knightTurn=false;
			System.out.println("the knight area is not occupied");
		}
	}
	
	@Tags({"passed"})
	public void passScene()
	{
		if (this.occupied&&!this.knightTurn)
		{
			final int x=800,y=300;
			final int dx=x-standKnight.getAvatarLocation().getX();
			final int dy=y-standKnight.getAvatarLocation().getY();
			standKnight.move(dx, dy);
			this.occupied=false;
			this.standKnight=null;
			this.knightTurn=false;
		}
	}
	
	@Tags({"failed"})
	public void failScene()
	{
		if (this.occupied)
		{
			final int x=600,y=300;
			if (this.knightTurn)//guard fails
			{
				//do nothing
			}
			else//knight fails
			{
				final int dx=x-this.standKnight.getAvatarLocation().getX();
				final int dy=y-this.standKnight.getAvatarLocation().getY();
				this.standKnight.move(dx, dy);
				this.standKnight=null;
				this.occupied=false;
				this.knightTurn=false;
			}
		}
	}
	
	//move all objects in this scene
	@Tags({"scroll"})
	public void scrollScene(int dx,int dy)
	{
		this.arthur.move(dx, dy);
		this.bridge.move(dx, dy);
		this.galahad.move(dx, dy);
		this.gorge.move(dx, dy);
		this.guard.move(dx, dy);
		this.guardArea.move(dx, dy);
		this.knightArea.move(dx, dy);
		this.lancelot.move(dx, dy);
		this.robin.move(dx, dy);
	}
	/*
	public boolean getOccupied()
	{
		return this.occupied;
	}*/
	public AvatarInterface getArthur()
	{
		return arthur;
	}
	public AvatarInterface getLancelot()
	{
		return lancelot;
	}
	
	public AvatarInterface getRobin()
	{
		return robin;
	}
	public AvatarInterface getGalahad()
	{
		return galahad;
	}
	public AvatarInterface getGuard()
	{
		return guard;
	}
	public ParallelLinesInterface getGorge()
	{
		return this.gorge;
	}
	public ParallelLinesInterface getBridge()
	{
		return this.bridge;
	}
	@Tags({"KnightArea"})
	public Shape getKnightArea()
	{
		return knightArea;
	}
	@Tags({"GuardArea"})
	public Shape getGuardAre()
	{
		return guardArea;
	}
}
