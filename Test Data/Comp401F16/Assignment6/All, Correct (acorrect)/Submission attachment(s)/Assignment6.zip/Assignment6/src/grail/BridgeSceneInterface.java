package grail;

public interface BridgeSceneInterface {
	public AvatarInterface getArthur();
	public AvatarInterface getLancelot();
	public AvatarInterface getRobin();
	public AvatarInterface getGalahad();
	public AvatarInterface getGuard();
	public void approachScene(AvatarInterface person);
	public void sayScene(String word);
	public void passScene();
	public void failScene();
	public void scrollScene(int dx,int dy);
}
