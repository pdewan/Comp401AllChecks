package grail.interfaces;

import util.annotations.Tags;

@Tags({"RotatingLine", "rotate"})
public interface RotatingLineInterface extends BoundedShapeInterface{

	public void setRadius(double r);
	public double getRadius();
	
	public void setAngle(double theta);
	public double getAngle();
	
	public void rotateByClockwiseDegrees(int degrees);
}
