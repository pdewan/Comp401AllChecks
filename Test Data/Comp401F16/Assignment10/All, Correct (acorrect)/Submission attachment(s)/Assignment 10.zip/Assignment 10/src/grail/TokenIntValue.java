package grail;

public interface TokenIntValue extends Token{
	public int getValue();
}
