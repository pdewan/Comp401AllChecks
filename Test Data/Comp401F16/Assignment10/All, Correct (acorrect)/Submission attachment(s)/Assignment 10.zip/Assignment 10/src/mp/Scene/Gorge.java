package mp.Scene;

public interface Gorge {
	public Line getG1();
	public Line getG2();
	public ImageShape getBeidge();
}
