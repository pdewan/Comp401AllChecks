package mp.Scene;

import java.awt.event.KeyListener;
import java.awt.event.MouseListener;

public interface BridgeSceneController extends KeyListener, MouseListener{

}
