package mp.command;

public interface SayCommand extends Runnable{

}
