package grail;
import util.annotations.Tags;
@Tags({"rotateRightArm"})
public class RotateRightArm  extends WordTokenImpl implements  TokenStringValue{
	public RotateRightArm(String input){
		super(input);
	}
}
