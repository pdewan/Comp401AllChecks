package grail;
import util.annotations.Tags;
@Tags({"proceedAll"})
public class ProceedAll  extends WordTokenImpl implements TokenStringValue{

	public ProceedAll(String input){
		super(input);
	}
}
