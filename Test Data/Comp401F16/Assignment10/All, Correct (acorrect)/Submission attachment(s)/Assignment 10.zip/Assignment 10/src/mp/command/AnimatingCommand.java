package mp.command;

public interface AnimatingCommand extends Runnable{
	
}
