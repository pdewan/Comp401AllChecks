package grail;

public interface Token {
	public void setInput(String input);
	public String getInput();
}
