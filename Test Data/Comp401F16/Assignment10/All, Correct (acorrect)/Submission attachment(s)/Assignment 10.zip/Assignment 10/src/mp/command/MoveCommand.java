package mp.command;

public interface MoveCommand extends Runnable{

}
