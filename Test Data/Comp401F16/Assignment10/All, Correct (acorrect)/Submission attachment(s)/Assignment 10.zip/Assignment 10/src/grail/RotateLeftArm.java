package grail;
import util.annotations.Tags;
@Tags({"rotateLeftArm"})
public class RotateLeftArm  extends WordTokenImpl implements TokenStringValue{
	public RotateLeftArm(String input){
		super(input);
	}
}
