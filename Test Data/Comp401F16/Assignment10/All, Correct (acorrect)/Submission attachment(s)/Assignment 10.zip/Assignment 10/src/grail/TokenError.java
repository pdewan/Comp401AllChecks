package grail;

public interface TokenError {
	public void setInput(char input);
	public char getInput();
}
