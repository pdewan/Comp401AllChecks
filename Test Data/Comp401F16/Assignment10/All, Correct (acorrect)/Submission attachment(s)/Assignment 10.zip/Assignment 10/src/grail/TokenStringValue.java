package grail;

public interface TokenStringValue extends Token{
	public String getValue();
}
