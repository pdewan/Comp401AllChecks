package grail.CharacterAnimation;

public interface StringShapeInterface extends LocatableShapeInt {

	public String getText();
	public void setText(String newText);
}
