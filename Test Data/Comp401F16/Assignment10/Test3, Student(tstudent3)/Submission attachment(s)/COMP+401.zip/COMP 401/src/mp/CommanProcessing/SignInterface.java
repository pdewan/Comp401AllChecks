package mp.CommanProcessing;


public interface SignInterface extends DefaultInterface {

}
