package grail.CharacterAnimation;

public interface CircleInterface extends LineInterface {

}
