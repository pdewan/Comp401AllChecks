package grail.CharacterAnimation;

public interface CommandInterpreterInt {

	public String getCommand();
	public void setCommand(String command);
	public String getStatus();
}
