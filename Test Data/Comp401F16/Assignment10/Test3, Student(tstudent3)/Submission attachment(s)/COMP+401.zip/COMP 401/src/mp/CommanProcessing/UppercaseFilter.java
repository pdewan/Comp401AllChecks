package mp.CommanProcessing;

public interface UppercaseFilter {
	public String getUppercaseLetters();
	void setInputString(String newString);

}
