package grail.CharacterAnimation;

import util.annotations.Tags;


@Tags({"Table"})
public interface TableInt {

	public void put(String Key, Object val);
	public Object get (String key);
}
