package grail.CharacterAnimation;

import java.beans.PropertyChangeListener;

public interface PropertyChangeMonitor extends PropertyChangeListener{

}
