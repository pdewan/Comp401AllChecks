package mp.CommanProcessing;

public interface DefaultInterface {

	void setInput(String newString);
	String getInput();
}
