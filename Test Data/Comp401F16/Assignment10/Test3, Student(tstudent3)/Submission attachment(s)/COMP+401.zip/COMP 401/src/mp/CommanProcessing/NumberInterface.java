package mp.CommanProcessing;


public interface NumberInterface extends DefaultInterface{

	int getValue();

	
}
