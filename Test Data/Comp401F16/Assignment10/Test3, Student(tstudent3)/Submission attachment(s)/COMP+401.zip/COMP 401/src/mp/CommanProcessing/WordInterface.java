package mp.CommanProcessing;


public interface WordInterface extends DefaultInterface {

	String getValue();

}
