package grail.CharacterAnimation;


public interface LineInterface extends BoundedShapeInt {
   
}
