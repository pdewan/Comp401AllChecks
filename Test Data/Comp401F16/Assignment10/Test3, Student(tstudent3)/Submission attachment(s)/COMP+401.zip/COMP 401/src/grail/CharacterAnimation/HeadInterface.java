package grail.CharacterAnimation;

public interface HeadInterface extends LocatableShapeInt{

    public String getImageFileName() ;  
    public void setImageFileName(String newVal);

	
}
