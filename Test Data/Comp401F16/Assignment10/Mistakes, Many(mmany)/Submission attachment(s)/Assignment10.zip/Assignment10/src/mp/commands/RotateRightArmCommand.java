package mp.commands;

import mp.tokens.WordToken;
import util.annotations.Tags;
@Tags({"rotateRightArm"})
public class RotateRightArmCommand extends WordToken{

	public RotateRightArmCommand(String input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

}
