package mp.commands;

import mp.tokens.WordToken;
import util.annotations.Tags;
@Tags({"move"})
public class MoveCommand extends WordToken{

	public MoveCommand(String input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

}
