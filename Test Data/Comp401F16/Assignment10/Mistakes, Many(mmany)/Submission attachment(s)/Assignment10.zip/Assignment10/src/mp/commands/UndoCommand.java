package mp.commands;

import mp.tokens.WordToken;
import util.annotations.Tags;
@Tags({"undo"})
public class UndoCommand extends WordToken{

	public UndoCommand(String input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

}
