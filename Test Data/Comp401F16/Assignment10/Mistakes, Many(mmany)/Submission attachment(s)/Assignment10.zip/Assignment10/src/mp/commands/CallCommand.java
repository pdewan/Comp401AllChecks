package mp.commands;

import mp.tokens.WordToken;
import util.annotations.Tags;
@Tags({"call"})
public class CallCommand extends WordToken{

	public CallCommand(String input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

}
