package mp.commands;

import mp.tokens.WordToken;
import util.annotations.Tags;
@Tags({"say"})
public class SayCommand extends WordToken{

	public SayCommand(String input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

}
