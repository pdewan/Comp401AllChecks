package mp.painter;

import java.awt.event.KeyListener;
import java.awt.event.MouseListener;

public interface BridgeSceneController extends MouseListener, KeyListener{

}
