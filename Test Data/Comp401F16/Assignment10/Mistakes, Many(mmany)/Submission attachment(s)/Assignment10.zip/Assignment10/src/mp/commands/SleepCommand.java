package mp.commands;

import mp.tokens.WordToken;
import util.annotations.Tags;
@Tags({"sleep"})
public class SleepCommand extends WordToken{

	public SleepCommand(String input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

}
