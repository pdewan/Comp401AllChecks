package mp.tokens;

public interface IntValueToken extends Token{
	public int getValue();
}
