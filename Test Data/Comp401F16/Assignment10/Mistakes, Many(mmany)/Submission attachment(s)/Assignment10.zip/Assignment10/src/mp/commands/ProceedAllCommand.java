package mp.commands;

import mp.tokens.WordToken;
import util.annotations.Tags;
@Tags({"proceedAll"})
public class ProceedAllCommand extends WordToken{

	public ProceedAllCommand(String input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

}
