package mp.commandobjects;

import mp.shapes.Avatar;

public interface Animator {
	public void animateAvatar(Avatar avatar);
}
