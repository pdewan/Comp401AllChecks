package mp.tokens;

public interface SignToken extends Token{

}
