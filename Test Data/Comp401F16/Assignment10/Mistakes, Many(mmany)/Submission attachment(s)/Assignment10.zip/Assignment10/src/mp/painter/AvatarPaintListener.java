package mp.painter;

public interface AvatarPaintListener extends PaintListener{

}
