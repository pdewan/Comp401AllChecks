package mp.commands;

import mp.tokens.WordToken;
import util.annotations.Tags;

@Tags({"wait"})
public class WaitCommand extends WordToken{

	public WaitCommand(String input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

}
