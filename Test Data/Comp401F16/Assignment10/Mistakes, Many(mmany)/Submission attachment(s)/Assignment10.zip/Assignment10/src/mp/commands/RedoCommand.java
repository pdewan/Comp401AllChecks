package mp.commands;

import mp.tokens.WordToken;
import util.annotations.Tags;
@Tags({"redo"})
public class RedoCommand extends WordToken{

	public RedoCommand(String input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

}
