package grail.mvc.view;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import grail.SingletonsCreator;
import grail.interfaces.BridgeSceneInterface;

public class InheritingBridgeScenePainter extends Component {
	
}
