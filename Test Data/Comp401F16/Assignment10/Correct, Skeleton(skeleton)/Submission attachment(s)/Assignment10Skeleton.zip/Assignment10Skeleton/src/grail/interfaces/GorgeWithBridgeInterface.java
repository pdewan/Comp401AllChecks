package grail.interfaces;


public interface GorgeWithBridgeInterface {

}