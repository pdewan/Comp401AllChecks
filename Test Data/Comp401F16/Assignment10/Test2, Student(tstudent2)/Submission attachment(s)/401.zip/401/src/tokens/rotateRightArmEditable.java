package tokens;

public interface rotateRightArmEditable {
	void setRotateRightArm(String token);
	String getInput();
}
