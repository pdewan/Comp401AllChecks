package tokens;

public interface WordEditable {

		void setWord(String token);
		String getInput();
		
}
