package tokens;

public interface redoEditable {
	void setRedo(String token);
	String getInput();
}
