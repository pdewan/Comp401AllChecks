package tokens;

public interface undoEditable {
	void setUndo(String token);
	String getInput();
}
