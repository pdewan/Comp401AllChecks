package tokens;

public interface defineEditable {
	void setDefine(String token);
	String getInput();
}
