package tokens;

public interface NumberRead {
	
	int getNumber();
}
