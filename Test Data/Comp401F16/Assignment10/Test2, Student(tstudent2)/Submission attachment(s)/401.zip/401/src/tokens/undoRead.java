package tokens;

public interface undoRead {
	String getUndo();
}
