package main;

public class ObjectWindow {
	// Used to test shapes in OE
	// Setting up parameters------------------------------------------------------------------------------------------------------------------------------------
		
		// Constructors--------------------------------------------------------------------------------------------------------------------------------------------
		public ObjectWindow(){
			BridgeScene Window = new BridgeScene();	
		}
}
