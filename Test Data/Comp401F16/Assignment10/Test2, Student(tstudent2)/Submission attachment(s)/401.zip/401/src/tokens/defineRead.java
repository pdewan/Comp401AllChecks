package tokens;

public interface defineRead {
	String getDefine();
}
