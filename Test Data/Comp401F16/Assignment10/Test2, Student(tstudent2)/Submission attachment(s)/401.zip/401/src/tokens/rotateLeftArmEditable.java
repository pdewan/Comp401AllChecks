package tokens;

public interface rotateLeftArmEditable {
	void setRotateLeftArm(String token);
	String getInput();
}
