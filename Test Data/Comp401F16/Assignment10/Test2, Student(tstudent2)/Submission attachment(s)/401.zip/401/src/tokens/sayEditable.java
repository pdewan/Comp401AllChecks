package tokens;

public interface sayEditable {
	void setSay(String token);
	String getInput();
}
