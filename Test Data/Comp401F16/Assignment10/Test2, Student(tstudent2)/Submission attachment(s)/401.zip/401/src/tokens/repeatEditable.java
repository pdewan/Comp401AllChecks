package tokens;

public interface repeatEditable {
	void setRepeat(String token);
	String getInput();
}
