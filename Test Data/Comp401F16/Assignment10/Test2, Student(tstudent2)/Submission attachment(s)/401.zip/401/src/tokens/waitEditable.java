package tokens;

public interface waitEditable {
	void setWait(String token);
	String getInput();
}
