package tokens;

public interface repeatRead {
	String getRepeat();
}
