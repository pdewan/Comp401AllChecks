package main;

import java.awt.event.MouseListener;

public interface BridgeSceneMouseListener extends MouseListener {

}
