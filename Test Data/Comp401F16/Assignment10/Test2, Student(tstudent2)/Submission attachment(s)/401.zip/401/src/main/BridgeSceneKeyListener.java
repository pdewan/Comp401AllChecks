package main;

import java.awt.event.KeyListener;

public interface BridgeSceneKeyListener extends KeyListener{

}
