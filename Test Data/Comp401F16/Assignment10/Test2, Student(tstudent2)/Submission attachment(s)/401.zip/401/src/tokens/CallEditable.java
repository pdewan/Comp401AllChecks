package tokens;

public interface CallEditable {
	void setCall(String token);
	String getInput();
}
