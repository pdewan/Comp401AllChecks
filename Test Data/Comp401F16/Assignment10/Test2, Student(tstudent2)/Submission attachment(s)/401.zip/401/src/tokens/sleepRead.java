package tokens;

public interface sleepRead {
	String getSleep();
}
