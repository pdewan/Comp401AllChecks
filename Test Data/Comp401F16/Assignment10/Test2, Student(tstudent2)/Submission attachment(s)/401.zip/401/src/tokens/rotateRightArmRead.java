package tokens;

public interface rotateRightArmRead {
	String getRotateRightArm();
}
