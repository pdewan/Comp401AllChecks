package tokens;

public interface NumberEditable {
	void setNumber(String token);
	String getInput();
}
