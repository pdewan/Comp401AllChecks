package tokens;

public interface moveEditable {
	void setMove(String token);
	String getInput();
}
