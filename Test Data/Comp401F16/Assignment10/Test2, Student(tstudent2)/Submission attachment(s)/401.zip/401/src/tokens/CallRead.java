package tokens;

public interface CallRead {
	String getCall();
}
