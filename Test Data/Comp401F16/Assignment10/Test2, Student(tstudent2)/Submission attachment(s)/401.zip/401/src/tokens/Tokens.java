package tokens;

public interface Tokens extends CallEditable, CallRead, defineEditable, defineRead, moveEditable, moveRead, proceedAllEditable, proceedAllRead, redoEditable, redoRead, repeatEditable, repeatRead, rotateLeftArmRead, rotateLeftArmEditable, rotateRightArmRead, rotateRightArmEditable, sayRead, sayEditable, sleepRead, sleepEditable, ThreadRead, ThreadEditable, undoRead, undoEditable, waitRead, waitEditable, approachInterface{

}
