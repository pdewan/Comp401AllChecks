package tokens;

public interface ThreadEditable {
	void setThread(String token);
	String getInput();
}
