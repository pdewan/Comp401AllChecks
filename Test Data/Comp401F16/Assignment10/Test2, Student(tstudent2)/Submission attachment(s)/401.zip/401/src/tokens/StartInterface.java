package tokens;

public interface StartInterface {
	void setStart(String in);
	String getStart();
}
