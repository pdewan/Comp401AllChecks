package tokens;

public interface moveRead {
	String getMove();
}
