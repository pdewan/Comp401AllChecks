package tokens;

public interface WordRead {
	
	String getWord();
}
