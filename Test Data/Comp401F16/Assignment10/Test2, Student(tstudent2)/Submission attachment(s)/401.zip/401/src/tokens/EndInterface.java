package tokens;

public interface EndInterface {
	void setEnd(String in);
	String getEnd();
}
