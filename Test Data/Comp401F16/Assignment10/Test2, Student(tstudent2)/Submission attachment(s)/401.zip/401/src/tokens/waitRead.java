package tokens;

public interface waitRead {
	String getWait();
}
