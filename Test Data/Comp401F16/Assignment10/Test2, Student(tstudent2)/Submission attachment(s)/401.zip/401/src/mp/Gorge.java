package mp;

public interface Gorge extends LocatableInter{
	public Line getG1();
	public Line getG2();
	public Rectangle getBridge();
}
