package tokens;

public interface ThreadRead {
	String getThread();
}
