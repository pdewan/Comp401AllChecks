package tokens;

public interface approachInterface {
	void setApproach(String token);
	String getInput();
	String getApproach();
}
