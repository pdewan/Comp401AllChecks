package tokens;

public interface QuoteInterface {
	void setQuote(String in);
	String getQuote();
}
