package tokens;

public interface rotateLeftArmRead {
	String getRotateLeftArm();
}
