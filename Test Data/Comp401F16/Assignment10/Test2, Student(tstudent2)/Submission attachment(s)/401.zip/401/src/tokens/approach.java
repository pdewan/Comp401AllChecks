package tokens;

import util.annotations.Tags;

@Tags ({"approach"})
public class approach extends Word implements Tokens {

	public approach(String in) {
		super(in);
		// TODO Auto-generated constructor stub
	}

}
