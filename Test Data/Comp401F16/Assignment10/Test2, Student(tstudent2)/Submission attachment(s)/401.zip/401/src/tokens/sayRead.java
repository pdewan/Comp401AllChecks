package tokens;

public interface sayRead {
	String getSay();
}
