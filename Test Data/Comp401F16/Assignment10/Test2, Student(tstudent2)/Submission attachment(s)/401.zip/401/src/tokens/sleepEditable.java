package tokens;

public interface sleepEditable {
	void setSleep(String token);
	String getInput();
}
