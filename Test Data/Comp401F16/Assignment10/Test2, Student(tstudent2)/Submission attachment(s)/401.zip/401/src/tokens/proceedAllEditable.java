package tokens;

public interface proceedAllEditable {
	void setProceedAll(String token);
	String getInput();
}
