package main;

public interface Animator {
	void animateAvatar();
}
