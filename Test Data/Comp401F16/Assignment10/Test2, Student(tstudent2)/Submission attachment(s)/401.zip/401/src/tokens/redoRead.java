package tokens;

public interface redoRead {
	String getRedo();
}
