package tokens;

public interface proceedAllRead {
	String getProceedAll();
}
