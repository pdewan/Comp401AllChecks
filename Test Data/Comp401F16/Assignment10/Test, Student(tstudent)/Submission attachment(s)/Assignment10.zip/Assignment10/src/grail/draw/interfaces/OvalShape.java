package grail.draw.interfaces;

public interface OvalShape extends ColorMutableShape{
	public boolean getFilled();
	public void setFilled(boolean isFilled);
}
