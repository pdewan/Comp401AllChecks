package grail.interfaces;

public interface NumberToken extends StoreToken {
	public int getValue();
}
