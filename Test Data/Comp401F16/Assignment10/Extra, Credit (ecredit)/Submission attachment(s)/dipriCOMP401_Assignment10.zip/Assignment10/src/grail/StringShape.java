package grail;

public interface StringShape extends Locatable {
public void setText(String aString);
public String getText();
}
