package grail;


public interface Number extends Token{
public int getValue();
}
