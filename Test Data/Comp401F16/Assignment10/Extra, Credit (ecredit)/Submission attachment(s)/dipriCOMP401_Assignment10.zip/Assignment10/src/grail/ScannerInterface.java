package grail;

public interface ScannerInterface {
public String getScannedString();
public void setScannedString (String aString);
public Token[] getToken();

}