package grail;

public interface StandingArea extends BoundedShape{
public void setWidth(int newWidth);
public void setHeight(int newHeight);
}
