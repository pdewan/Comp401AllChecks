package grail;


public interface AngleInterface{
public Line getLeftLine();
public Line getRightLine();
public void moveAngle(int x, int y);

}
