package grail;

import util.annotations.Tags;

@Tags({"Animator"})
public interface Animator {
public void animate();
}
