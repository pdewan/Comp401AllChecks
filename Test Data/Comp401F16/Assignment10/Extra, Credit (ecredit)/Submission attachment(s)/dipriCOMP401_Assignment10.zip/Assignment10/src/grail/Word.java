package grail;


public interface Word extends Token{
public String getValue();
}
