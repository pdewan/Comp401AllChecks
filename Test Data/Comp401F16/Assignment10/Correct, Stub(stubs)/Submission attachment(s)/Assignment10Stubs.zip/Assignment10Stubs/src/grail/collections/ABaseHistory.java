package grail.collections;

import grail.interfaces.BaseHistory;
import grail.interfaces.Token;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;

@StructurePattern(StructurePatternNames.VECTOR_PATTERN)
public class ABaseHistory implements BaseHistory {

	@Override
	public void addElement(Token element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Token elementAt(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
