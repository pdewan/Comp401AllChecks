package grail.mvc.view;

import bus.uigen.widgets.Painter;
import grail.SingletonsCreator;
import grail.interfaces.BridgeSceneInterface;
import grail.interfaces.mvc.DelegatingBridgeSceneViewInterface;
import grail.interfaces.mvc.PaintingViewMaster;
import grail.interfaces.mvc.PaintingViewModule;
import util.annotations.Tags;

@Tags({"DelegatingBridgeSceneView"})
public class DelegatingBridgeSceneView implements DelegatingBridgeSceneViewInterface{
	
}
